from django import forms
from django.contrib.auth.models import User

from .choices import CHOICES_NUMBERS, CHOICES_EXP
from .models import *


class ArtistReviewForm(forms.ModelForm):
    review_overall = forms.ChoiceField(
        choices=CHOICES_NUMBERS,
        label='Ocena ogólna',
        widget=forms.Select(),
        required=True
    )

    review_execution = forms.ChoiceField(
        choices=CHOICES_NUMBERS,
        label='Wykonanie tatuażu',
        widget=forms.Select(),
        required=True
    )

    review_atmosphere = forms.ChoiceField(
        choices=CHOICES_NUMBERS,
        label='Atmosfera',
        help_text='Swoboda rozmowy z tatuatorem, zapewnione napoje w cenie tatuażu itd.',
        widget=forms.Select(),
        required=True
    )

    review_price = forms.ChoiceField(
        choices=CHOICES_EXP,
        label='Cena',
        help_text='Cena wykonania tatuaży w stosunku do jakości wykonania.',
        widget=forms.Select(),
        required=True
    )

    class Meta:
        model = ArtistReview
        fields = ('review_overall', 'review_execution', 'review_atmosphere', 'review_price', 'review_description',)


class StudioReviewForm(forms.ModelForm):
    review_overall = forms.ChoiceField(
        choices=CHOICES_NUMBERS,
        label='Ocena ogólna',
        widget=forms.Select(),
        required=True
    )

    review_atmosphere = forms.ChoiceField(
        choices=CHOICES_NUMBERS,
        label='Dodatki',
        help_text='Typu przekaska, napoje itd',
        widget=forms.Select(),
        required=True
    )

    review_price = forms.ChoiceField(
        choices=CHOICES_EXP,
        label='Cena',
        help_text='Cena wykonania tatuaży w stosunku do jakości wykonania.',
        widget=forms.Select(),
        required=True
    )

    class Meta:
        model = StudioReview
        fields = ('review_overall', 'review_atmosphere', 'review_price', 'review_description',)
