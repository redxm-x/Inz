from django.contrib import admin
from .models import City, Studio, StudioReview, Artist, ArtistReview, Offers, Finished

# Register your models here.


@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ('name',)


@admin.register(Studio)
class StudioAdmin(admin.ModelAdmin):
    list_display = ('city', 'name',)


@admin.register(Artist)
class ArtistAdmin(admin.ModelAdmin):
    list_display = ('city', 'studio', 'first_name', 'last_name')


@admin.register(ArtistReview)
class ArtistReviewAdmin(admin.ModelAdmin):
    list_display = ('artist', 'review_overall', 'user')


@admin.register(Offers)
class OffersAdmin(admin.ModelAdmin):
    list_display = ('artist',)


@admin.register(Finished)
class FinishedAdmin(admin.ModelAdmin):
    list_display = ('artist',)
