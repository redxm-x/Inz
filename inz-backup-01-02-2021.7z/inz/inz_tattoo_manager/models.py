from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from taggit.managers import TaggableManager
from .choices import CHOICES_NUMBERS, CHOICES_EXP


def avg(score, number):
    score = sum(score)
    result = score / number

    return result


def upload_to_studio(instance, filename):
    return f'static/studios/{instance.name}/{filename}'


def upload_to_artist(instance, filename):
    return f'static/artists/{instance.name}/{filename}'


def upload_to_artist_offer(instance, filename):
    return f'static/artists/{instance.artist}/offers/{filename}'


def upload_to_artist_finished(instance, filename):
    return f'static/artists/{instance.artist}/finished/{filename}'


def upload_to_review_studio(instance, filename):
    return f'static/review/studios/{instance.studio}/{instance.user}/{filename}'


def upload_to_review_artist(instance, filename):
    return f'static/review/artists/{instance.artist}/{instance.user}/{filename}'


class City(models.Model):
    name = models.CharField(
        max_length=40,
        default=None
    )

    def __str__(self):
        return self.name


class Studio(models.Model):
    city = models.ForeignKey(
        to="City",
        on_delete=models.CASCADE,
        default=None
    )

    address = models.CharField(
        max_length=60,
        default=''
    )

    icon = models.ImageField(
        default=None,
        upload_to=upload_to_studio,
    )

    name = models.CharField(
        max_length=50,
        default='Brak'
    )

    def __str__(self):
        return self.name


class StudioReview(models.Model):
    studio = models.ForeignKey(
        to="Studio",
        on_delete=models.CASCADE
    )

    review_overall = models.FloatField(
        choices=CHOICES_NUMBERS,
        default=3
    )

    review_atmosphere = models.FloatField(
        choices=CHOICES_NUMBERS,
        default=3
    )

    review_price = models.IntegerField(
        choices=CHOICES_EXP,
        default=3
    )

    review_description = models.TextField(
        max_length=255,
        verbose_name='Opis recenzji:'
    )

    created_date = models.DateTimeField(
        auto_now_add=True
    )

    user = models.CharField(
        max_length=50
    )

    def __int__(self):
        return self.review_overall


class Artist(models.Model):
    icon = models.ImageField(
        upload_to=upload_to_artist,
        default=None
    )

    city = models.ForeignKey(
        to="City",
        on_delete=models.CASCADE
    )

    studio = models.ForeignKey(
        to="Studio",
        on_delete=models.CASCADE,
        default='Brak',
        blank=True
    )

    name = models.CharField(
        max_length=25,
        unique=True
    )

    first_name = models.CharField(
        max_length=25
    )

    last_name = models.CharField(
        max_length=30
    )

    tag = TaggableManager()

    def __str__(self):
        return self.name


class ArtistReview(models.Model):
    artist = models.ForeignKey(
        to="Artist",
        on_delete=models.CASCADE
    )

    review_overall = models.FloatField(
        choices=CHOICES_NUMBERS,
        default=3
    )

    review_atmosphere = models.FloatField(
        choices=CHOICES_NUMBERS,
        default=3
    )

    review_execution = models.FloatField(
        choices=CHOICES_NUMBERS,
        default=3
    )

    review_price = models.IntegerField(
        choices=CHOICES_EXP,
        default=3
    )

    review_description = models.TextField(
        max_length=255,
        blank=True,
        verbose_name='Opis recenzji:'
    )

    user = models.CharField(
        max_length=50,
        blank=True
    )
    created_date = models.DateTimeField(
        auto_now_add=True
    )

    def __int__(self):
        return self.review_overall


class DateSessionArtist(models.Model):
    artist = models.ForeignKey(
        to='Artist',
        on_delete=models.CASCADE
    )

    free_date = models.DateField()
    busy_date = models.DateField()


class Offers(models.Model):
    artist = models.ForeignKey(
        to='Artist',
        on_delete=models.CASCADE
    )

    offer_price = models.CharField(
        max_length=4
    )

    offer_description = models.CharField(
        max_length=5000
    )

    offer_image = models.ImageField(
        upload_to=upload_to_artist_offer
    )


class Finished(models.Model):
    artist = models.ForeignKey(
        to='Artist',
        on_delete=models.CASCADE
    )

    finished_title = models.CharField(
        max_length=50
    )

    finished_image = models.ImageField(
        upload_to=upload_to_artist_finished
    )
