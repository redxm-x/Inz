from django.urls import path
from .views import *


app_name = 'inz_tattoo_manager'

urlpatterns = [
    path('', IndexView.as_view(), name='index'),
    path('search-results/', SearchResultsView.as_view(), name='search_results'),
    path('studios', StudioListView.as_view(), name='studio_list'),
    path('studios/<int:pk>', StudioDetailView.as_view(), name='studio_detail'),
    path('artists', ArtistListView.as_view(), name='artist_list'),
    path('artists/<int:pk>', ArtistDetailView.as_view(), name='artist_detail'),
    path('artists-review/<int:pk>', ArtistReviewView.as_view(), name='artist_review_detail'),
    path('artists-review/<int:pk>/add', get_artist_review, name='artist_review_add'),
    path('studio-review/<int:pk>', StudioReviewView.as_view(), name='studio_review_detail'),
    path('studio-review/<int:pk>/add', get_studio_review, name='studio_review_add'),
    path('cities', CityListView.as_view(), name='city_list'),
    path('cities/<int:pk>', CityDetailView.as_view(), name='city_detail'),
    path('user/<int:pk>', UserView.as_view(), name='user_detail'),
]

