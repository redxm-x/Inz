def handle_uploaded_file(f, artist, user, filename):
    with open(f'static/review/artists/{artist}/{user}/{filename}', 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)

