from django.db.models import Q, Avg, F
from django.forms import forms
from django.core.files.base import ContentFile
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render
from django.template import loader
from django.urls import reverse
from django.views.generic import *
from django.contrib.auth.models import User
from .models import City, Studio, Artist, ArtistReview, StudioReview, upload_to_review_artist
from .forms import ArtistReviewForm
from .functions import *


class BaseView(View):

    def get(self, request):
        return render(request, 'inz_tattoo_manager/base.html')


class IndexView(ListView):
    model = Studio
    template_name = 'inz_tattoo_manager/index.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_review_price'] = ArtistReview.objects.values('artist__name').annotate(average_price=Avg(
            'review_price'
        ))
        context['artist_review_list_avg'] = ArtistReview.objects.values('artist__name').annotate(average_rating=Avg(
            (
                    F('review_overall') +
                    F('review_atmosphere') +
                    F('review_execution')
            ) / 3
        ))
        context['artist_list'] = Artist.objects.all()
        context['city_list'] = City.objects.all()
        return context


class SearchResultsView(ListView):
    model = City
    template_name = 'inz_tattoo_manager/search_results.html'

    def get_queryset(self):
        query = self.request.GET.get('q')
        object_list = Artist.objects.filter(
            Q(name__icontains=query) | Q(city__name__icontains=query) | Q(tag__name__icontains=query)
        )
        return object_list

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        context['artist_review_price'] = ArtistReview.objects.values('artist__name').annotate(average_price=Avg(
            'review_price'
        ))
        context['artist_review_list_avg'] = ArtistReview.objects.values('artist__name').annotate(average_rating=Avg(
            (
                    F('review_overall') +
                    F('review_atmosphere') +
                    F('review_execution')
            ) / 3
        ))
        return context


class CityListView(ListView):
    model = City

    context_object_name = 'all_cities'
    queryset = City.objects.all()
    template_name = 'inz_tattoo_manager/city_list.html'

    ordering = ['name']


class CityDetailView(DetailView):
    model = City

    template_name = 'inz_tattoo_manager/city_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        return context


class StudioListView(ListView):
    model = Studio

    context_object_name = 'all_studios'
    queryset = Studio.objects.all()
    template_name = 'inz_tattoo_manager/studio_list.html'

    ordering = ['name']


class StudioDetailView(DetailView):
    model = Studio

    template_name = 'inz_tattoo_manager/studio_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        return context


class ArtistListView(ListView):
    model = Artist

    context_object_name = 'all_artists'
    queryset = Artist.objects.all()
    template_name = 'inz_tattoo_manager/artist_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        context['review_list'] = ArtistReview.objects.values('artist__name').annotate(average_rating=Avg(
            (
                F('review_overall') +
                F('review_atmosphere') +
                F('review_execution')
            ) / 3
        ))
        context['counted_review_list'] = ArtistReview.objects.all().count()
        return context

    ordering = ['name']


class ArtistDetailView(DetailView):
    model = Artist

    template_name = 'inz_tattoo_manager/artist_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        context['review_list'] = ArtistReview.objects.all()
        return context


class ArtistReviewView(DetailView):
    model = ArtistReview

    template_name = 'inz_tattoo_manager/artist_review_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['user_list'] = User.objects.all()
        context['review_list'] = ArtistReview.objects.all()
        return context


def get_review(request, pk):
    artist = Artist.objects.get(pk=pk)
    user = request.user
    model = ArtistReview

    if request.method == 'POST':
        form = ArtistReviewForm(request.POST)

        if form.is_valid():
            review_form = form.save(commit=False)
            review_form.user = user
            review_form.artist = artist
            # review_form.review_image = model(review_image=handle_uploaded_file(
            #     f=request.FILES['review_image'], artist=artist, user=user, filename=request.FILES['review_image'].name))
            # review_form.review_image.save(review_form.review_image, ContentFile(content=review_form.review_image))
            review_form.save()

            return HttpResponseRedirect(reverse('inz_tattoo_manager:index'))

    else:
        form = ArtistReviewForm()

    context = {
        'form': form,
        'artist': artist,
    }

    template = loader.get_template('inz_tattoo_manager/artist_review_add.html')
    return HttpResponse(template.render(context, request))


class UserView(DetailView):
    model = User

    template_name = 'inz_tattoo_manager/user_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        context['review_list'] = ArtistReview.objects.all()
        return context





