from django.db.models import Q
from django.shortcuts import render
from django.views.generic import *
from .models import City, Studio, Artist, ArtistReview


class TestView(View):

    def get(self, request):
        return render(request, 'inz_tattoo_manager/index.html')


class SearchResultsView(ListView):
    model = City
    template_name = 'inz_tattoo_manager/search_results.html'

    def get_queryset(self):
        query = self.request.GET.get('q')
        object_list = City.objects.filter(
            Q(name__icontains=query)
        )
        return object_list

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        return context


class CityListView(ListView):
    model = City

    context_object_name = 'all_cities'
    queryset = City.objects.all()
    template_name = 'inz_tattoo_manager/city_list.html'

    ordering = ['name']


class CityDetailView(DetailView):
    model = City

    template_name = 'inz_tattoo_manager/city_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        return context


class StudioListView(ListView):
    model = Studio

    context_object_name = 'all_studios'
    queryset = Studio.objects.all()
    template_name = 'inz_tattoo_manager/studio_list.html'

    ordering = ['name']


class StudioDetailView(DetailView):
    model = Studio

    template_name = 'inz_tattoo_manager/studio_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        return context


class ArtistListView(ListView):
    model = Artist

    context_object_name = 'all_artists'
    queryset = Artist.objects.all()
    template_name = 'inz_tattoo_manager/artist_list.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        context['review_list'] = ArtistReview.objects.all()
        context['counted_review_list'] = ArtistReview.objects.filter().count()
        return context

    ordering = ['name']


class ArtistDetailView(DetailView):
    model = Artist

    template_name = 'inz_tattoo_manager/artist_detail.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['studio_list'] = Studio.objects.all()
        context['artist_list'] = Artist.objects.all()
        context['review_list'] = ArtistReview.objects.all()
        return context



