from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


def avg(score, number):
    score = sum(score)
    result = score / number

    return result


class City(models.Model):
    name = models.CharField(
        max_length=40,
        default=None
    )

    def __str__(self):
        return self.name


def upload_to_studio(instance, filename):
    return f'static/studios/{instance.name}/{filename}'


def upload_to_artist(instance, filename):
    return f'static/artists/{instance.name}/{filename}'


def upload_to_review_studio(instance, filename):
    return f'static/review/studios/{instance.studio}/{instance.user}/{filename}'


def upload_to_review_artist(instance, filename):
    return f'static/review/artists/{instance.artist}/{instance.user}/{filename}'


class Studio(models.Model):
    city = models.ForeignKey(
        to="City",
        on_delete=models.CASCADE
    )

    address = models.CharField(
        max_length=60,
        default=''
    )

    icon = models.ImageField(
        default=None,
        upload_to=upload_to_studio,
    )

    name = models.CharField(
        max_length=50,
        default=None
    )

    def __str__(self):
        return self.name


class StudioReview(models.Model):
    studio = models.ForeignKey(
        to="Studio",
        on_delete=models.CASCADE
    )

    review = models.IntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )

    review_description = models.TextField(
        max_length=255,
    )

    review_image = models.ImageField(
        upload_to=upload_to_review_studio
    )

    user = models.CharField(
        max_length=50
    )

    def __int__(self):
        return self.review


class Artist(models.Model):
    icon = models.ImageField(
        upload_to=upload_to_artist,
        default=None
    )

    city = models.ForeignKey(
        to="City",
        on_delete=models.CASCADE
    )

    studio = models.ForeignKey(
        to="Studio",
        on_delete=models.CASCADE,
        blank=True
    )

    name = models.CharField(
        max_length=25
    )

    first_name = models.CharField(
        max_length=25
    )

    last_name = models.CharField(
        max_length=30
    )

    def __str__(self):
        return self.name


class ArtistReview(models.Model):
    artist = models.ForeignKey(
        to="Artist",
        on_delete=models.CASCADE
    )

    review = models.IntegerField(
        default=1,
        validators=[MinValueValidator(1), MaxValueValidator(5)]
    )

    review_description = models.TextField(
        max_length=255,
    )

    user = models.CharField(
        max_length=50
    )

    review_image = models.ImageField(
        upload_to=upload_to_review_artist,
        default=None,
    )

    def __int__(self):
        return self.review



