from django.apps import AppConfig


class InzTattooManagerConfig(AppConfig):
    name = 'inz_tattoo_manager'
